class Razonimate {
  constructor() {
    this.elements = document.querySelectorAll(`[data-razon]`);
  }

  init() {
    window.addEventListener('scroll', this.checkInView.bind(this));
  }

  checkInView() {
    this.elements.forEach(element => {
      const elementRect = element.getBoundingClientRect();
      if (elementRect.top >= 0 && elementRect.bottom <= window.innerHeight) {
        switch (element.dataset.razon) {
          case 'fade':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('fade');
            break;
          case 'fade-up':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('fade-up');
            break;
          case 'fade-down':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('fade-down');
            break;
          case 'fade-left':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('fade-left');
            break;
          case 'fade-right':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('fade-right');
            break;
          case 'fade-up-left':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('fade-up-left');
            break;
          case 'fade-up-right':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('fade-up-right');
            break;
          case 'fade-down-left':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('fade-down-left');
            break;
          case 'fade-down-right':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('fade-down-right');
            break;
          case 'flip-left':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('flip-left');
            break;
          case 'flip-right':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('flip-right');
            break;
          case 'flip-up':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('flip-up');
            break;
          case 'flip-down':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('flip-down');
            break;
          case 'zoom-in':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('zoom-in');
            break;
          case 'zoom-in-up':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('zoom-in-up');
            break;
          case 'zoom-in-down':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('zoom-in-down');
            break;
          case 'zoom-in-left':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('zoom-in-left');
            break;
          case 'zoom-in-right':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('zoom-in-right');
            break;
          case 'slide-up':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('slide-up');
            break;
          case 'slide-down':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('slide-down');
            break;
          case 'slide-left':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('slide-left');
            break;
          case 'slide-right':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('slide-right');
            break;
          case 'rotate-left':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('rotate-left');
            break;
          case 'rotate-right':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('rotate-right');
            break;
          case 'shuffle-left':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('shuffle-left');
            break;
          case 'shuffle-right':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('shuffle-right');
            break;
          case 'skew-left':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('skew-left');
            break;
          case 'skew-right':
            element.style.transition = `opacity ${element.dataset.razonDuration / 2000}s, transform ${element.dataset.razonDuration / 2000}s`;
            element.classList.add('skew-right');
            break;
        }
      } else {
        element.style.transition = '';
        element.classList.remove(element.dataset.razon);
        element.classList.remove('fade');
        element.classList.remove('fade-up');
        element.classList.remove('fade-down');
        element.classList.remove('fade-left');
        element.classList.remove('fade-right');
        element.classList.remove('fade-up-left');
        element.classList.remove('fade-up-right');
        element.classList.remove('fade-down-left');
        element.classList.remove('fade-down-right');
        element.classList.remove('flip-left');
        element.classList.remove('flip-right');
        element.classList.remove('flip-up');
        element.classList.remove('flip-down');
        element.classList.remove('zoom-in');
        element.classList.remove('zoom-in-up');
        element.classList.remove('zoom-in-down');
        element.classList.remove('zoom-in-left');
        element.classList.remove('zoom-in-right');
        element.classList.remove('slide-up');
        element.classList.remove('slide-down');
        element.classList.remove('slide-left');
        element.classList.remove('slide-right');
        element.classList.remove('rotate-left');
        element.classList.remove('rotate-right');
        element.classList.remove('shuffle-left');
        element.classList.remove('shuffle-right');
        element.classList.remove('skew-left');
        element.classList.remove('skew-right');
      }
    });
  }
}

